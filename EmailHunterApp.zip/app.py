import socket
from flask import Flask, render_template, request, jsonify, send_file
from flask_socketio import SocketIO, emit
import pandas as pd
import os
import re
import time
import threading
from urllib.parse import urlparse, urljoin, unquote
from collections import deque
import requests
from bs4 import BeautifulSoup
import csv
from io import BytesIO
from datetime import datetime
import random
import logging
from fake_useragent import UserAgent
from bs4.element import Comment # Added for comment extraction

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 全局配置
MAX_RETRIES = 5
MAX_THREADS = 5
PROXY_ROTATION_INTERVAL = 10
DEFAULT_TIMEOUT = 30

class AdvancedCrawler:
    def __init__(self, log_callback):
        self.log_callback = log_callback
        self.ua = UserAgent()
        self.session = self._create_session()
        self.proxy_list = self._load_proxy_list()
        self.current_proxy_index = 0
        self.last_proxy_rotation = time.time()
        self.browser = None
        self.playwright = None

    def _load_proxy_list(self):
        """加载代理列表"""
        try:
            # 这里可以从文件加载或使用代理服务API
            return [
                'socks5://127.0.0.1:9050',  # Tor代理
                'http://proxy1.example.com:8080',
                'http://proxy2.example.com:8080',
            ]
        except Exception as e:
            self.log_callback(f"加载代理列表失败: {e}")
            return []

    def _create_session(self):
        """创建请求会话"""
        session = requests.Session()
        session.headers.update({
            'User-Agent': self.ua.random,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5,zh-CN;q=0.3',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        return session

    def _rotate_proxy(self):
        """轮换代理"""
        if time.time() - self.last_proxy_rotation > PROXY_ROTATION_INTERVAL and self.proxy_list:
            self.current_proxy_index = (self.current_proxy_index + 1) % len(self.proxy_list)
            self.session.proxies = {'http': self.proxy_list[self.current_proxy_index],
                                  'https': self.proxy_list[self.current_proxy_index]}
            self.last_proxy_rotation = time.time()

    def _setup_undetected_chrome(self):
        """设置无检测Chrome"""
        # This method is no longer needed as we are not using selenium directly.
        # If selenium is still needed, it should be re-added and configured.
        pass

    def _setup_playwright(self):
        """设置Playwright"""
        # This method is no longer needed as we are not using playwright directly.
        # If playwright is still needed, it should be re-added and configured.
        pass

    async def _fetch_with_aiohttp(self, url):
        """使用aiohttp异步获取页面"""
        # This method is no longer needed as we are not using aiohttp directly.
        # If aiohttp is still needed, it should be re-added and configured.
        pass

    def _extract_emails_from_js(self, js_content):
        """从JavaScript中提取邮箱"""
        emails = set()
        # 基本模式
        patterns = [
            r'[\'"]([\w\.-]+@[\w\.-]+\.\w+)[\'"]',
            r'[\'"]([\w\.-]+\s*@\s*[\w\.-]+\.\w+)[\'"]',
            r'[\'"]([\w\.-]+\[at\][\w\.-]+\[dot\]\w+)[\'"]',
        ]
        
        # 解码混淆
        js_content = js_content.replace('\\x40', '@')
        js_content = re.sub(r'\\x([0-9a-fA-F]{2})', lambda m: chr(int(m.group(1), 16)), js_content)
        
        # 查找所有可能的邮箱
        for pattern in patterns:
            matches = re.findall(pattern, js_content)
            emails.update(matches)
        
        return emails

    def _get_page_with_multiple_methods(self, url):
        """使用多种方法获取页面内容"""
        methods = [
            self._get_with_requests,
            self._get_with_selenium,
            self._get_with_playwright,
            self._get_with_tor
        ]
        
        for method in methods:
            try:
                content = method(url)
                if content:
                    return content
            except Exception as e:
                self.log_callback(f"方法 {method.__name__} 失败: {e}")
                continue
        
        return None

    def _get_with_requests(self, url):
        """使用requests获取页面"""
        self._rotate_proxy()
        response = self.session.get(url, timeout=DEFAULT_TIMEOUT)
        return response.text

    def _get_with_selenium(self, url):
        """使用Selenium获取页面"""
        # This method is no longer needed as we are not using selenium directly.
        # If selenium is still needed, it should be re-added and configured.
        pass

    def _get_with_playwright(self, url):
        """使用Playwright获取页面"""
        # This method is no longer needed as we are not using playwright directly.
        # If playwright is still needed, it should be re-added and configured.
        pass

    def _get_with_tor(self, url):
        """通过Tor网络获取页面"""
        try:
            # This part of the code is no longer needed as we are not using Tor directly.
            # If Tor is still needed, it should be re-added and configured.
            pass
        except Exception as e:
            self.log_callback(f"Tor请求失败: {e}")
            return None

    def close(self):
        """清理资源"""
        # This method is no longer needed as we are not using selenium or playwright directly.
        pass

def get_local_ip():
    """获取本机IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def get_random_user_agent():
    """返回随机User-Agent"""
    ua = UserAgent()
    return ua.random

def get_random_referrer(url):
    """返回合理的 Referrer"""
    parsed_url = urlparse(url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
    referrers = [
        'https://www.google.com/',
        'https://www.bing.com/',
        'https://www.baidu.com/',
        base_url,
        f"{base_url}/",
        f"{base_url}/about",
    ]
    return random.choice(referrers)

def create_session(base_url):
    """创建一个配置好的会话"""
    session = requests.Session()
    
    # 基本请求头
    session.headers.update({
        'User-Agent': get_random_user_agent(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5,zh-CN;q=0.3',
        'Accept-Encoding': 'gzip, deflate, br',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Referer': get_random_referrer(base_url)
    })
    
    # 添加常见的Cookie
    session.cookies.update({
        'cookieconsent': 'accepted',
        'timezone': 'Asia/Shanghai',
    })
    
    return session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'a_very_secret_key_that_is_secure_and_random'
socketio = SocketIO(app, async_mode='threading')  # 使用 threading 模式替代 eventlet

# --- 全局变量和文件设置 ---
RESULTS_CSV_FILE = 'results.csv'
all_results_for_frontend = {}
lock = threading.Lock()

def load_initial_data():
    """只在服务启动时运行，加载所有历史数据"""
    global all_results_for_frontend
    with lock:
        # 确保CSV文件存在并有标题行
        if not os.path.exists(RESULTS_CSV_FILE):
            with open(RESULTS_CSV_FILE, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['Email', 'Domain', 'Category'])
        
        # 从CSV加载历史数据到内存
        all_results_for_frontend = {}
        try:
            with open(RESULTS_CSV_FILE, 'r', newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                next(reader) # Skip header
                for row in reader:
                    email, domain, category = row
                    if domain not in all_results_for_frontend:
                        all_results_for_frontend[domain] = {'category': category, 'emails': []}
                    if email not in all_results_for_frontend[domain]['emails']:
                        all_results_for_frontend[domain]['emails'].append(email)
        except (IOError, StopIteration):
             print(f"提示: {RESULTS_CSV_FILE} 文件为空或不存在，将自动创建。")

def get_media_specific_patterns(domain):
    """针对媒体网站的特殊邮箱模式"""
    patterns = [
        # 新闻/媒体相关邮箱
        f'newsroom@{domain}',
        f'news@{domain}',
        f'press@{domain}',
        f'editor@{domain}',
        f'editorial@{domain}',
        f'tips@{domain}',
        f'submissions@{domain}',
        f'letters@{domain}',
        f'feedback@{domain}',
        f'corrections@{domain}',
        
        # 广告/商务相关
        f'advertising@{domain}',
        f'ads@{domain}',
        f'business@{domain}',
        f'partnerships@{domain}',
        f'media@{domain}',
        
        # 订阅/会员相关
        f'subscriptions@{domain}',
        f'subscribe@{domain}',
        f'membership@{domain}',
        f'subscribers@{domain}',
        
        # 技术支持
        f'helpdesk@{domain}',
        f'support@{domain}',
        f'tech@{domain}',
        f'webmaster@{domain}',
    ]
    return patterns

def get_priority_paths_for_media():
    """获取媒体网站常见的重要路径"""
    return [
        '/about',
        '/contact',
        '/about-us',
        '/contact-us',
        '/newsroom',
        '/news-tips',
        '/submit-news',
        '/submit',
        '/press',
        '/media-kit',
        '/advertising',
        '/staff',
        '/masthead',
        '/editorial-team',
        '/editors',
        '/team',
        '/careers',
        '/jobs',
        '/work-with-us',
        '/feedback',
        '/corrections',
        '/help',
        '/support',
        '/subscribe',
        '/subscription',
        '/membership',
        '/corporate',
        '/privacy',
        '/terms',
        '/sitemap',
    ]

def extract_emails_from_text(text):
    """增强的邮箱提取函数"""
    emails = set()
    
    # 1. 标准邮箱模式
    patterns = [
        # 基本邮箱格式
        r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        
        # 带保护的邮箱格式（更多变体）
        r'[a-zA-Z0-9._%+-]+\s*[\[\({<]\s*at\s*[\]\)}>]\s*[a-zA-Z0-9.-]+\s*[\[\({<]\s*dot\s*[\]\)}>]\s*[a-zA-Z]{2,}',
        r'[a-zA-Z0-9._%+-]+\s+at\s+[a-zA-Z0-9.-]+\s+dot\s+[a-zA-Z]{2,}',
        r'[a-zA-Z0-9._%+-]+\s*@\s*[a-zA-Z0-9.-]+\s*\.\s*[a-zA-Z]{2,}',
        r'[a-zA-Z0-9._%+-]+\s*\[at\]\s*[a-zA-Z0-9.-]+\s*\[dot\]\s*[a-zA-Z]{2,}',
        
        # JavaScript混淆格式
        r'[a-zA-Z0-9._%+-]+\s*\+\s*[\'"]\s*@\s*[\'"]?\s*\+\s*[a-zA-Z0-9.-]+',
        r'[\'"]mailto:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})[\'"]',
        
        # 媒体网站特有格式
        r'email:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        r'e-mail:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        r'send\s+(?:email|mail|message|tip)\s+to:?\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        r'contact\s+(?:us|me|editor|staff)\s+at:?\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
    ]
    
    for pattern in patterns:
        found = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        for email in found:
            if isinstance(email, tuple):
                email = email[0]
            email = email.lower()
            # 处理各种at/dot替换
            replacements = [
                (' at ', '@'), ('[@]', '@'), ('(@)', '@'), ('[at]', '@'), ('(at)', '@'),
                (' dot ', '.'), ('[.]', '.'), ('(.)', '.'), ('[dot]', '.'), ('(dot)', '.'),
                ('\u0040', '@'), ('&#64;', '@'), ('&#x40;', '@'),
                ('&lt;', '<'), ('&gt;', '>'), ('&quot;', '"'), ('&amp;', '&'),
                ('\n', ''), ('\r', ''), ('\t', ''),
            ]
            for old, new in replacements:
                email = email.replace(old, new)
            
            # 清理特殊字符
            email = re.sub(r'[\s\[\](){}<>|+\'"]', '', email)
            
            # 验证邮箱格式
            if '@' in email and '.' in email.split('@')[1]:
                # 清理邮箱首尾的特殊字符
                email = re.sub(r'^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$', '', email)
                if re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
                    emails.add(email)
    
    return emails

def extract_potential_contact_pages(soup, current_url):
    """提取可能包含联系信息的页面链接"""
    contact_links = set()
    contact_keywords = [
        'contact', 'about', 'team', 'staff', 'people', 'support',
        'help', 'career', 'job', 'press', 'media', 'news',
        'kontakt', 'about-us', 'about_us', 'aboutus', 'contact-us',
        'contact_us', 'contactus', 'connect', 'reach', 'touch',
        'directory', 'meet', 'who-we-are', 'who_we_are', 'whoweare',
        'our-team', 'our_team', 'ourteam', 'company', 'organization',
        'department', 'office', 'location', 'address', 'feedback',
    ]
    
    for a in soup.find_all(['a', 'area']):
        href = a.get('href', '').lower()
        text = a.get_text().lower()
        title = a.get('title', '').lower()
        
        if any(keyword in href or keyword in text or keyword in title 
               for keyword in contact_keywords):
            try:
                full_url = urljoin(current_url, href)
                contact_links.add((full_url, 0))  # 0表示优先级最高
            except:
                continue
    
    return contact_links

def search_email_in_google(domain, session):
    """通过 Google 搜索查找邮箱"""
    search_queries = [
        f'site:{domain} email OR mail OR contact',
        f'site:{domain} "@{domain}"',
        f'site:{domain} "contact us" OR "get in touch" OR "email us"',
        f'site:{domain} "mailto:"',
    ]
    
    found_emails = set()
    for query in search_queries:
        try:
            search_url = f'https://www.google.com/search?q={requests.utils.quote(query)}'
            response = session.get(search_url, timeout=10)
            if response.status_code == 200:
                found_emails.update(extract_emails_from_text(response.text))
            time.sleep(random.uniform(2, 4))  # 避免触发 Google 限制
        except Exception as e:
            logger.warning(f"Google search failed for {domain}: {e}")
    return found_emails

def search_email_in_bing(domain, session):
    """通过 Bing 搜索查找邮箱"""
    search_queries = [
        f'site:{domain} email OR mail OR contact',
        f'site:{domain} "@{domain}"',
        f'site:{domain} "contact us" OR "get in touch" OR "email us"',
    ]
    
    found_emails = set()
    for query in search_queries:
        try:
            search_url = f'https://www.bing.com/search?q={requests.utils.quote(query)}'
            response = session.get(search_url, timeout=10)
            if response.status_code == 200:
                found_emails.update(extract_emails_from_text(response.text))
            time.sleep(random.uniform(2, 4))
        except Exception as e:
            logger.warning(f"Bing search failed for {domain}: {e}")
    return found_emails

def try_common_email_patterns(domain):
    """生成常见的邮箱模式"""
    common_patterns = [
        f'info@{domain}',
        f'contact@{domain}',
        f'support@{domain}',
        f'hello@{domain}',
        f'admin@{domain}',
        f'sales@{domain}',
        f'marketing@{domain}',
        f'press@{domain}',
        f'media@{domain}',
        f'help@{domain}',
        f'team@{domain}',
        f'careers@{domain}',
        f'hr@{domain}',
        f'webmaster@{domain}',
        f'office@{domain}',
    ]
    return common_patterns

def verify_email(email):
    """验证邮箱是否有效"""
    try:
        domain = email.split('@')[1]
        # 检查MX记录
        import dns.resolver
        mx_records = dns.resolver.resolve(domain, 'MX')
        return len(mx_records) > 0
    except:
        return False

def crawl_website_pure(url, max_pages, log_callback, result_callback):
    """优化的爬虫函数"""
    session_emails = set()
    try:
        # 规范化URL
        if not url.startswith(('http://', 'https://')):
            url = f'https://{url}'
        
        parsed_url = urlparse(url)
        base_domain = parsed_url.netloc
        if not base_domain:
            base_domain = url.split('/')[0].strip()
        if not base_domain:
            log_callback(f'   - ❌ 无效URL，跳过: {url}')
            return

        # 尝试不同的URL变体
        url_variants = [
            f'https://{base_domain}',
            f'http://{base_domain}',
            f'https://www.{base_domain}',
            f'http://www.{base_domain}'
        ]

        # 添加媒体网站特有的优先路径
        priority_paths = get_priority_paths_for_media()
        
        # 将优先路径添加到URL变体中
        for base_url in url_variants[:]:  # 使用切片创建副本以避免在迭代时修改
            for path in priority_paths:
                url_variants.append(base_url + path)
                url_variants.append(base_url + path + '.html')
                url_variants.append(base_url + path + '/')

        urls_to_visit = deque([(u, 0) for u in url_variants])
        visited_urls = set()
        pages_crawled = 0
        log_callback(f'   - 🚀 开始爬取: {base_domain}')

        # 创建多个不同配置的会话
        sessions = [create_session(url) for _ in range(3)]  # 创建3个不同的会话
        current_session_index = 0

        def rotate_session():
            nonlocal current_session_index
            current_session_index = (current_session_index + 1) % len(sessions)
            return sessions[current_session_index]

        def try_fetch_url(url, session, max_retries=3):
            """尝试使用不同的方法获取URL内容"""
            for attempt in range(max_retries):
                try:
                    # 每次重试都更新请求头
                    session.headers.update({
                        'User-Agent': get_random_user_agent(),
                        'Referer': get_random_referrer(url)
                    })

                    response = session.get(url, timeout=15, allow_redirects=True)
                    
                    if response.status_code in [403, 401, 429]:
                        # 如果被禁止，等待并切换会话
                        time.sleep(random.uniform(2, 5))
                        session = rotate_session()
                        continue
                        
                    response.raise_for_status()
                    return response
                except Exception as e:
                    if attempt == max_retries - 1:
                        log_callback(f'     - ⚠️ 页面访问失败: {url} - {str(e)}')
                        return None
                    time.sleep(random.uniform(1, 3))
                    session = rotate_session()
            return None

        while urls_to_visit and pages_crawled < max_pages:
            current_url, depth = urls_to_visit.popleft()
            if current_url in visited_urls:
                continue

            visited_urls.add(current_url)
            pages_crawled += 1
            log_callback(f'     - 🔎 ({pages_crawled}/{max_pages}) {current_url}')

            # 获取页面内容
            response = try_fetch_url(current_url, sessions[current_session_index])
            if not response:
                continue

            # 尝试不同的编码方式
            content = None
            for encoding in ['utf-8', 'iso-8859-1', 'cp1252', 'gbk', 'big5', 'shift_jis', 'euc-jp', 'euc-kr']:
                try:
                    response.encoding = encoding
                    content = response.text
                    if content and any(char.isalpha() for char in content):  # 验证内容是否有效
                        break
                except:
                    continue

            if not content:
                continue

            # 1. 从页面内容中提取邮箱
            found_emails = extract_emails_from_text(content)

            # 2. 解析HTML
            soup = BeautifulSoup(content, 'html.parser')

            # 3. 检查所有可能包含邮箱的元素
            for tag in soup.find_all(['a', 'span', 'div', 'p', 'li', 'td', 'script', 'meta']):
                # 检查标签的所有属性
                for attr in ['href', 'data-email', 'content', 'value', 'title', 'alt']:
                    if value := tag.get(attr):
                        found_emails.update(extract_emails_from_text(str(value)))
                
                # 检查标签的文本内容
                if tag.string:
                    found_emails.update(extract_emails_from_text(str(tag.string)))

            # 4. 检查注释中的邮箱
            for comment in soup.find_all(string=lambda text: isinstance(text, Comment)):
                found_emails.update(extract_emails_from_text(str(comment)))

            # 5. 检查JavaScript文件
            for script in soup.find_all('script', src=True):
                try:
                    script_url = urljoin(current_url, script['src'])
                    if script_url.endswith('.js'):
                        script_response = try_fetch_url(script_url, sessions[current_session_index])
                        if script_response:
                            found_emails.update(extract_emails_from_text(script_response.text))
                except:
                    continue

            if found_emails:
                # 过滤和清理邮箱
                cleaned_emails = set()
                for email in found_emails:
                    email = email.lower().strip()
                    # 验证邮箱格式
                    if re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
                        cleaned_emails.add(email)

                # 过滤出与域名相关的邮箱
                filtered_emails = {email for email in cleaned_emails 
                                if any(email.lower().endswith(f'@{domain}') 
                                      for domain in [base_domain] + [f'{subdomain}.{base_domain}' 
                                                                  for subdomain in ['mail', 'email', 'contact', 'info', 'support', 'press', 
                                                                                  'media', 'sales', 'marketing', 'jobs', 'careers', 'hr',
                                                                                  'help', 'service', 'enquiry', 'enquiries', 'admin']])}

                if filtered_emails:
                    newly_found = filtered_emails - session_emails
                    if newly_found:
                        log_callback(f'       - ✅ 找到 {len(newly_found)} 个相关邮箱')
                        session_emails.update(newly_found)
                        result_callback(newly_found)

            # 6. 提取更多链接
            contact_links = extract_potential_contact_pages(soup, current_url)
            for link, priority in contact_links:
                if link not in visited_urls:
                    if priority == 0:  # 高优先级链接
                        urls_to_visit.appendleft((link, depth))
                    else:
                        urls_to_visit.append((link, depth + 1))

            # 提取其他链接
            for a_tag in soup.find_all(['a', 'area', 'link']):
                href = a_tag.get('href', '')
                if href:
                    try:
                        link = urljoin(current_url, href).split('#')[0]
                        parsed_link = urlparse(link)
                        # 检查是否是同域名的链接
                        if (parsed_link.netloc == base_domain or 
                            parsed_link.netloc.endswith('.' + base_domain)) and \
                           link not in visited_urls and \
                           not any(link.endswith(ext) for ext in ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.css', '.zip', '.rar', '.doc', '.docx', '.mp3', '.mp4', '.avi', '.mov']):
                            urls_to_visit.append((link, depth + 1))
                    except:
                        continue

            # 动态调整抓取间隔
            if depth > 2:
                time.sleep(random.uniform(1.5, 3))  # 深层页面降低频率
            else:
                time.sleep(random.uniform(0.3, 1))  # 主要页面保持较快速度

        # 如果常规爬取没有找到邮箱，尝试其他方法
        if not session_emails:
            log_callback(f'     - 📧 未找到邮箱，尝试其他方法...')
            
            # 1. 尝试搜索引擎
            search_emails = set()
            search_emails.update(search_email_in_google(base_domain, sessions[0]))
            search_emails.update(search_email_in_bing(base_domain, sessions[1]))
            
            # 2. 尝试媒体网站特有的邮箱模式
            media_emails = set(get_media_specific_patterns(base_domain))
            
            # 3. 尝试常见邮箱模式
            common_emails = set(try_common_email_patterns(base_domain))
            
            # 4. 验证找到的邮箱
            all_potential_emails = search_emails | media_emails | common_emails
            verified_emails = set()
            
            for email in all_potential_emails:
                if verify_email(email):
                    verified_emails.add(email)
                    log_callback(f'       - ✅ 验证邮箱有效: {email}')
            
            if verified_emails:
                session_emails.update(verified_emails)
                result_callback(verified_emails)
            else:
                # 5. 如果还是没找到，记录一个默认邮箱模式
                default_emails = [f'info@{base_domain}', f'contact@{base_domain}', f'press@{base_domain}']
                for default_email in default_emails:
                    if verify_email(default_email):
                        session_emails.add(default_email)
                        result_callback({default_email})
                        log_callback(f'       - ✅ 使用默认邮箱: {default_email}')
                        break
                else:
                    log_callback(f'     - ⚠️ 警告: 未能在 {base_domain} 找到任何有效邮箱')

    except Exception as e:
        log_callback(f'     - ❌ 爬取时发生严重错误: {e}')
        
    return bool(session_emails)  # 返回是否找到邮箱


# --- 后台任务控制器 ---
def background_task_controller(filepath):
    global all_results_for_frontend
    
    def log_to_frontend(message):
        socketio.emit('log', {'data': message})

    try:
        df = pd.read_excel(filepath, header=0, engine='openpyxl')
        print("Excel文件列名:", df.columns.tolist())
        print("Excel文件形状:", df.shape)
        
        # 只保留第一列不为空的行
        df_cleaned = df.dropna(subset=[df.columns[0]])
        
        # 如果只有一列，所有网站分类设为"未分类"
        if len(df.columns) == 1:
            sites = [{'url': str(row[0]), 'category': "未分类"} for _, row in df_cleaned.iterrows()]
        else:
            # 如果有多列，使用最后一列作为分类（如果为空则设为"未分类"）
            sites = [{'url': str(row[0]), 
                     'category': str(row[-1]) if pd.notna(row[-1]) else "未分类"} 
                    for _, row in df_cleaned.iterrows()]

        total = len(sites)
        log_to_frontend(f"文件解析成功，准备处理 {total} 个网站。")

        for i, site in enumerate(sites, 1):
            url = site['url']
            category = site['category']
            domain = urlparse(f"https://{url.replace('https://','').replace('http://','')}").netloc
            
            log_to_frontend(f'▶️ ({i}/{total}) 处理: {url} (分类: {category})')
            start_url = url if url.startswith('http') else f'https://{url}'
            
            def process_results_for_site(found_emails):
                with lock:
                    if domain not in all_results_for_frontend:
                        all_results_for_frontend[domain] = {'category': category, 'emails': []}
                    
                    newly_added_to_global = []
                    for email in found_emails:
                        if email not in all_results_for_frontend[domain]['emails']:
                            all_results_for_frontend[domain]['emails'].append(email)
                            newly_added_to_global.append(email)
                    
                    if newly_added_to_global:
                        try:
                            with open(RESULTS_CSV_FILE, 'a', newline='', encoding='utf-8') as f:
                                writer = csv.writer(f)
                                for email in newly_added_to_global:
                                    writer.writerow([email, domain, category])
                        except IOError as e:
                            log_to_frontend(f"⚠️ 写入文件 {RESULTS_CSV_FILE} 出错: {e}")
                
                socketio.emit('update_results', all_results_for_frontend)
            
            crawl_website_pure(start_url, 50, log_to_frontend, process_results_for_site)
            log_to_frontend(f'👍 在 {domain} 的爬取任务完成。')

        log_to_frontend('🎉🎉🎉 全部任务完成！ 🎉🎉🎉')
    except Exception as e:
        log_to_frontend(f'❌ 处理文件时发生严重错误: {e}')


# --- Flask 路由和 SocketIO 事件 ---
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' in request.files:
        file = request.files['file']
        if file.filename and file.filename.endswith('.xlsx'):
            # Create uploads directory if it doesn't exist
            if not os.path.exists('uploads'):
                os.makedirs('uploads')
            
            filepath = os.path.join('uploads', file.filename)
            file.save(filepath)
            
            # Start the background task
            socketio.start_background_task(background_task_controller, filepath)
            
            return jsonify({'status': 'success', 'message': '文件上传成功，任务开始!'})
    return jsonify({'status': 'error', 'message': '文件上传失败或文件类型不正确'}), 400

@app.route('/download_excel')
def download_excel():
    """将结果导出为Excel文件"""
    try:
        # 将数据转换为DataFrame格式
        rows = []
        for domain, data in all_results_for_frontend.items():
            category = data['category']
            for email in data['emails']:
                rows.append({
                    '域名': domain,
                    '分类': category,
                    '邮箱': email,
                    '发现时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        
        df = pd.DataFrame(rows)
        
        # 创建一个内存中的Excel文件
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='邮箱列表')
        output.seek(0)
        
        # 生成文件名
        filename = f'email_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@socketio.on('connect')
def handle_connect():
    """处理新的客户端连接，只发送当前数据，不修改"""
    emit('log', {'data': '🔌 已连接到服务器，历史数据已发送。'})
    emit('update_results', all_results_for_frontend)


if __name__ == '__main__':
    load_initial_data() # 在服务启动时加载数据
    port = 5001
    local_ip = get_local_ip()
    print(f"服务器启动，本地访问地址: http://127.0.0.1:{port}")
    print(f"局域网访问地址: http://{local_ip}:{port}")
    socketio.run(app, host='0.0.0.0', port=port, debug=True, use_reloader=False) 